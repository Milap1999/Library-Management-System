from django.contrib import admin
from library.models import *
# Register your models here.


@admin.register(StudentLogin)
class ModuleAdmin(admin.ModelAdmin):
    list_display = ['user_name',
                    'role',
                    'user_email',
                    'user_password',
                    ]


@admin.register(Students)
class ModuleAdmin(admin.ModelAdmin):
    list_display = ['id', 'student_id',
                    'roll_number',
                    'fullname',
                    'address',
                    'program',
                    'Guardian_name',
                    'Email',
                    ]


@admin.register(Book)
class ModuleAdmin(admin.ModelAdmin):
    list_display = ['id', 
                    'book_title',
                    'book_author',
                    'book_pages',
                    'summary',
                    ]


@admin.register(BookInstance)
class ModuleAdmin(admin.ModelAdmin):
    list_display = [ 'id',
                    'Books_issue_id',
                    'book',
                    'book_number',
                    'Is_borrowed',
                    ]


@admin.register(Book_Issue)
class ModuleAdmin(admin.ModelAdmin):
    list_display = ['id',
                    'student',
                    'book_instance',
                    'issue_date',
                    'due_date',
                    'date_returned',
                    'remarks_on_issue',
                    'remarks_on_return',
                    ]
