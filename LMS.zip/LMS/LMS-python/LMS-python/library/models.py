from django.db import models
from datetime import datetime,timedelta
import uuid
from django.utils import timezone
from django.db.models.signals import post_save
from django.dispatch import receiver

class StudentLogin(models.Model):
    STATUS= [
        ("Admin","Admin"),
        ("Student","Student"),
    ]
    user_name=models.CharField(max_length=254,blank=True)
    role = models.CharField(max_length=100,choices=STATUS ,default=STATUS[1][1])
    user_email=models.EmailField(blank=True)
    user_password=models.CharField(max_length=254,blank=True)
    
    def __str__(self):
        return self.user_name
    
    class Meta():
        db_table='LMS_student_login'     





class Students(models.Model):
    student_id = models.ForeignKey(StudentLogin,on_delete=models.CASCADE,null=True)
    roll_number = models.CharField(max_length=100,unique=True)
    fullname = models.CharField(max_length=100)
    address = models.CharField(max_length=100)
    program = models.CharField(max_length=100)
    Guardian_name=models.CharField(max_length=100,help_text="parent/guardian full name")
    Email=models.EmailField(max_length=100,help_text="Guardian/parent e-mail")
    def __str__(self):
        return self.fullname
    
    class Meta():
        db_table='LMS_student_details'     


class Book(models.Model):
    Choice=[
        ("No","No"),
        ("Yes","Yes")
    ]
    book_title = models.CharField(max_length=200)
    book_author = models.CharField(max_length=100)
    book_pages = models.PositiveIntegerField()
    is_Available = models.CharField(max_length=23,choices=Choice,default=Choice[1][1])
    summary=models.TextField(max_length=500, help_text="Summary about the book",null=True,blank=True)
    def __str__(self):
        return self.book_title
    
    class Meta():
        db_table='LMS_Book_details' 

class BookInstance(models.Model):
     # student_name = models.ForeignKey(Students, on_delete=models.CASCADE,blank=True,null=True)

    Books_issue_id=models.UUIDField(default=uuid.uuid4,help_text="Book unique id across the Library")
    book=models.ForeignKey(Book, on_delete=models.CASCADE,null=True)
    book_number=models.PositiveIntegerField(null=True,help_text="Book number for books of the save kind")
    Is_borrowed = models.BooleanField(default=False)
    
    def __str__(self):
        return str(self.book)
    
    class Meta():
        db_table='LMS_BookInstance_details' 


def get_returndate():
    return datetime.today() + timedelta(days=8)

class Book_Issue(models.Model):
    student = models.ForeignKey(Students, on_delete=models.CASCADE)
    book_instance = models.ForeignKey(BookInstance, on_delete=models.CASCADE)
    issue_date = models.DateTimeField(auto_now=True,help_text="Date the book is issued")
    due_date = models.DateTimeField(default=get_returndate(),help_text="Date the book is due to")
    date_returned=models.DateField(null=True, blank=True,help_text="Date the book is returned")
    remarks_on_issue = models.CharField(max_length=100, default="Book in good condition", help_text="Book remarks/condition during issue")
    remarks_on_return = models.CharField(max_length=100, default="Book in good condition", help_text="Book remarks/condition during return")

    def __str__(self):
        return str(self.student)
    
    class Meta():
        db_table='LMS_Book_Issue_details'
        
        
@receiver(post_save, sender=BookInstance)
def update_book_availability(sender, instance, **kwargs):
    if instance.Is_borrowed:
        instance.book.is_Available = "No"
    else:
        instance.book.is_Available = "Yes"
    instance.book.save()