from rest_framework.views import APIView
from rest_framework.response import Response 
from rest_framework.decorators import api_view
from library.models import *
from library.serializers import *
from rest_framework import status
from rest_framework_simplejwt.tokens import RefreshToken


####################################  StudentLogin Details API ##############################################

@api_view(['GET', 'POST', 'DELETE'])
# @permission_classes([IsAuthenticated])
def Student_login_details(request):
    if request.method == 'GET':
        StudentLoginModule = StudentLogin.objects.all()        
        StudentLoginModuleserializer = StudentLoginSerializers(StudentLoginModule, many=True)
        return Response({"data":"true","message": "Student Login Lists", "response":StudentLoginModuleserializer.data},status=status.HTTP_200_OK)
    
 
    elif request.method == 'POST':
        module_serializer = StudentLoginSerializers(data=request.data)
        if module_serializer.is_valid():
            module_serializer.save()
            return Response({"data":"true", "message": "Student Added Sucessfuly!!","response":module_serializer.data},status=status.HTTP_201_CREATED) 
        return Response({"status_code":401,"responce":module_serializer.errors},status=status.HTTP_400_BAD_REQUEST) 
    
    elif request.method == 'DELETE':
        count = StudentLogin.objects.all().delete()
        return Response({'message': '{} Student was deleted successfully!'.format(count[0])}, status=status.HTTP_204_NO_CONTENT)
    
    
 
@api_view(['GET', 'PUT', 'DELETE'])
# @permission_classes([IsAuthenticated])
def Student_login_details_Put(request, pk):
    try: 
       Studentmodule = StudentLogin.objects.get(pk=pk) 
    except StudentLogin.DoesNotExist: 
        return Response({'message': 'Student does not exist'}, status=status.HTTP_404_NOT_FOUND) 
         
    if request.method == 'GET': 
        module_serializer = StudentLoginSerializers(Studentmodule) 
        return Response({"data":"true","message": "Student Details Get Successfully", "response":module_serializer.data},status=status.HTTP_200_OK)  
 
    elif request.method == 'PUT': 
        module_serializer = StudentLoginSerializers(Studentmodule, data=request.data) 
        if module_serializer.is_valid(): 
            module_serializer.save() 
            return Response({"data":"true", "message": "Student updated Sucessfuly!!","response":module_serializer.data},status=status.HTTP_201_CREATED) 
        return Response({"responce":module_serializer.errors},status=status.HTTP_400_BAD_REQUEST)  
         
    elif request.method == 'DELETE': 
        Studentmodule.delete() 
        return Response({'message': 'Students was deleted successfully!'}, status=status.HTTP_204_NO_CONTENT)
    

##################  Student details API  ###########################3

@api_view(['GET', 'POST', 'DELETE'])
# @permission_classes([IsAuthenticated])
def Student_details(request):
    if request.method == 'GET':
        StudentLoginModule = Students.objects.all()        
        StudentLoginModuleserializer = StudentsSerializers(StudentLoginModule, many=True)
        return Response({"data":"true","message": "Students Details Lists", "response":StudentLoginModuleserializer.data},status=status.HTTP_200_OK)
    
 
    elif request.method == 'POST':
        print(request.data)
        module_serializer = StudentsSerializers(data=request.data)
        if module_serializer.is_valid():
            module_serializer.save()
            return Response({"data":"true", "message": "Student Details Add Sucessfuly!!","response":module_serializer.data},status=status.HTTP_201_CREATED) 
        return Response({"status_code":401,"responce":module_serializer.errors},status=status.HTTP_400_BAD_REQUEST) 
    
    elif request.method == 'DELETE':
        count = Students.objects.all().delete()
        return Response({'message': '{} Student Details was deleted successfully!'.format(count[0])}, status=status.HTTP_204_NO_CONTENT)
    
    
 
@api_view(['GET', 'PUT', 'DELETE'])
# @permission_classes([IsAuthenticated])
def Student_details_Put(request, pk):
    try: 
       Studentmodule = Students.objects.get(pk=pk) 
    except Students.DoesNotExist: 
        return Response({'message': 'Student Detail  does not exist'}, status=status.HTTP_404_NOT_FOUND) 
         
    if request.method == 'GET': 
        module_serializer = StudentsSerializers(Studentmodule) 
        return Response({"data":"true","message": "Students Details Get Successfully", "response":module_serializer.data},status=status.HTTP_200_OK)  
 
    elif request.method == 'PUT': 
        module_serializer = StudentsSerializers(Studentmodule, data=request.data) 
        if module_serializer.is_valid(): 
            module_serializer.save() 
            return Response({"data":"true", "message": "Student Detail updated Sucessfuly!!","response":module_serializer.data},status=status.HTTP_201_CREATED) 
        return Response({"responce":module_serializer.errors},status=status.HTTP_400_BAD_REQUEST)  
         
    elif request.method == 'DELETE': 
        Studentmodule.delete() 
        return Response({'message': 'Student Detail was deleted successfully!'}, status=status.HTTP_204_NO_CONTENT)
    


################################## BOOKS API ##########################################################



@api_view(['GET', 'POST', 'DELETE'])
# @permission_classes([IsAuthenticated])
def Books_Details(request):
    if request.method == 'GET':
        BooksModule = Book.objects.all()        
        BooksModuleserializer = BookSerializers(BooksModule, many=True)
        return Response({"data":"true","message": "Books Details Lists", "response":BooksModuleserializer.data},status=status.HTTP_200_OK)
    
 
    elif request.method == 'POST':
        module_serializer = BookSerializers(data=request.data)
        if module_serializer.is_valid():
            module_serializer.save()
            return Response({"data":"true", "message": "Book Details Add Sucessfuly!!","response":module_serializer.data},status=status.HTTP_201_CREATED) 
        return Response({"status_code":401,"responce":module_serializer.errors},status=status.HTTP_400_BAD_REQUEST) 
    
    elif request.method == 'DELETE':
        count = Book.objects.all().delete()
        return Response({'message': '{} Book Details was deleted successfully!'.format(count[0])}, status=status.HTTP_204_NO_CONTENT)
    
    
 
@api_view(['GET', 'PUT', 'DELETE'])
# @permission_classes([IsAuthenticated])
def Books_Details_Put(request, pk):
    try: 
       Studentmodule = Book.objects.get(pk=pk) 
    except Book.DoesNotExist: 
        return Response({'message': 'Book Detail  does not exist'}, status=status.HTTP_404_NOT_FOUND) 
         
    if request.method == 'GET': 
        module_serializer = BookSerializers(Studentmodule) 
        return Response({"data":"true","message": "Books Details Get Successfully", "response":module_serializer.data},status=status.HTTP_200_OK)  
 
    elif request.method == 'PUT': 
        module_serializer = BookSerializers(Studentmodule, data=request.data) 
        if module_serializer.is_valid(): 
            module_serializer.save() 
            return Response({"data":"true", "message": "Book Detail updated Sucessfuly!!","response":module_serializer.data},status=status.HTTP_201_CREATED) 
        return Response({"responce":module_serializer.errors},status=status.HTTP_400_BAD_REQUEST)  
         
    elif request.method == 'DELETE': 
        Studentmodule.delete() 
        return Response({'message': 'Book Detail was deleted successfully!'}, status=status.HTTP_204_NO_CONTENT)
    

####################################### BookInstance API #########################################


@api_view(['GET', 'POST', 'DELETE'])
# @permission_classes([IsAuthenticated])
def BookInstance_details(request):
    if request.method == 'GET':
        BooksModule = BookInstance.objects.all()  
        
        BooksModuleserializer = BookInstanceSerializersGET(BooksModule, many=True)
        return Response({"data":"true","message": "BookInstance Lists", "response":BooksModuleserializer.data},status=status.HTTP_200_OK)
    
 
    elif request.method == 'POST':
        print(request.data)
        module_serializer = BookInstanceSerializers(data=request.data)
        if module_serializer.is_valid():
            module_serializer.save()
            return Response({"data":"true", "message": "BookInstance Add Sucessfuly!!","response":module_serializer.data},status=status.HTTP_201_CREATED) 
        return Response({"status_code":401,"responce":module_serializer.errors},status=status.HTTP_400_BAD_REQUEST) 
    
    elif request.method == 'DELETE':
        count = BookInstance.objects.all().delete()
        return Response({'message': '{} BookInstance was deleted successfully!'.format(count[0])}, status=status.HTTP_204_NO_CONTENT)
    
    
 
@api_view(['GET', 'PUT', 'DELETE'])
# @permission_classes([IsAuthenticated])
def BookInstance_details_Put(request, pk):
    try: 
       Studentmodule = BookInstance.objects.get(pk=pk) 
    except BookInstance.DoesNotExist: 
        return Response({'message': 'BookInstance  does not exist'}, status=status.HTTP_404_NOT_FOUND) 
         
    if request.method == 'GET': 
        module_serializer = BookInstanceSerializersGET(Studentmodule) 
        return Response({"data":"true","message": "BookInstance Get Successfully", "response":module_serializer.data},status=status.HTTP_200_OK)  
 
    elif request.method == 'PUT': 
        module_serializer = BookInstanceSerializers(Studentmodule, data=request.data) 
        if module_serializer.is_valid(): 
            module_serializer.save() 
            return Response({"data":"true", "message": "BookInstance updated Sucessfuly!!","response":module_serializer.data},status=status.HTTP_201_CREATED) 
        return Response({"responce":module_serializer.errors},status=status.HTTP_400_BAD_REQUEST)  
         
    elif request.method == 'DELETE': 
        Studentmodule.delete() 
        return Response({'message': 'BookInstance was deleted successfully!'}, status=status.HTTP_204_NO_CONTENT)
    



################################# Book_Issue API ##################################################


@api_view(['GET', 'POST', 'DELETE'])
# @permission_classes([IsAuthenticated])
def Book_Issue_details(request):
    if request.method == 'GET':
        BooksModule = Book_Issue.objects.all()        
        BooksModuleserializer = Book_IssueSerializersGET(BooksModule, many=True)
        return Response({"data":"true","message": "Books Issue Lists", "response":BooksModuleserializer.data},status=status.HTTP_200_OK)
    
 
    elif request.method == 'POST':
        print(request.data)
        # {'student': 1, 'book_instance': 1}
        

        module_serializer = Book_IssueSerializers(data=request.data)
        if module_serializer.is_valid():
            module_serializer.save()
            return Response({"data":"true", "message": "Books Issue  Add Sucessfuly!!","response":module_serializer.data},status=status.HTTP_201_CREATED) 
        return Response({"status_code":401,"responce":module_serializer.errors},status=status.HTTP_400_BAD_REQUEST) 
    
    elif request.method == 'DELETE':
        count = Book_Issue.objects.all().delete()
        return Response({'message': '{} Books Issue  was deleted successfully!'.format(count[0])}, status=status.HTTP_204_NO_CONTENT)
    
    
 
@api_view(['GET', 'PUT', 'DELETE'])
# @permission_classes([IsAuthenticated])
def Book_Issue_details_Put(request, pk):
    try: 
       Studentmodule = Book_Issue.objects.get(pk=pk) 
    except Book_Issue.DoesNotExist: 
        return Response({'message': 'Issue Books does not exist'}, status=status.HTTP_404_NOT_FOUND) 
         
    if request.method == 'GET': 
        module_serializer = Book_IssueSerializersGET(Studentmodule) 
        return Response({"data":"true","message": "Books Issue Get Successfully", "response":module_serializer.data},status=status.HTTP_200_OK)  
 
    elif request.method == 'PUT': 
        module_serializer = Book_IssueSerializers(Studentmodule, data=request.data) 
        if module_serializer.is_valid(): 
            module_serializer.save() 
            return Response({"data":"true", "message": "Books Issue updated Sucessfuly!!","response":module_serializer.data},status=status.HTTP_201_CREATED) 
        return Response({"responce":module_serializer.errors},status=status.HTTP_400_BAD_REQUEST)  
         
    elif request.method == 'DELETE': 
        Studentmodule.delete() 
        return Response({'message': 'Books Issue was deleted successfully!'}, status=status.HTTP_204_NO_CONTENT)
    

############################## LogIN API ############################################



def get_tokens_for_user(user):
    refresh = RefreshToken.for_user(user)
    return str(refresh.access_token)




class LoginView(APIView):
    def post(self, request, format=None):
        print(request.data)
        login_serializer=StudentLoginSerializers(data=request.data)

        if login_serializer.is_valid():
            user_email=login_serializer.data.get('user_email')
            user_password=login_serializer.data.get('user_password')
            try:
                user=StudentLogin.objects.get(user_email=user_email, user_password=user_password)
                token=get_tokens_for_user(user)
            except StudentLogin.DoesNotExist:
                return Response({"status_code": 401,'error':{'Email or password is not valid'}},status=status.HTTP_400_BAD_REQUEST)
            userDetails = StudentLogin.objects.get(user_email=user.user_email) # retrieve user by user_id
            tutorials_serializer = StudentLoginSerializers(userDetails)
            
            return Response({"data":"true","status_code": 200,"access_token":str(token),"message": "Login Successfully","response":tutorials_serializer.data},status=status.HTTP_200_OK)
        return Response({"status_code":401,"responce":login_serializer.errors},status=status.HTTP_400_BAD_REQUEST)
    



#     {
# "user_email" : "Akshat22@gmail.com",
# "user_password":"1234"
# }
