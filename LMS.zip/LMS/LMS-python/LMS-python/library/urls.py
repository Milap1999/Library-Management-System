from django.urls import path
from library import views
from .views import LoginView

urlpatterns = [
    path('login/',LoginView.as_view()),

    path('StudentLogin/', views.Student_login_details),
    path('StudentLogin/<int:pk>', views.Student_login_details_Put),


    path('Students/', views.Student_details),
    path('Students/<int:pk>', views.Student_details_Put),


    path('Book/', views.Books_Details),
    path('Book/<int:pk>', views.Books_Details_Put),


    path('BookInstance/', views.BookInstance_details),
    path('BookInstance/<int:pk>', views.BookInstance_details_Put),



    path('Book_Issue/', views.Book_Issue_details),
    path('Book_Issue/<int:pk>', views.Book_Issue_details_Put),

]
