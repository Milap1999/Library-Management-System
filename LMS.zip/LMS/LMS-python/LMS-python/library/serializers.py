from rest_framework import serializers
from library.models import *


class StudentLoginSerializers(serializers.ModelSerializer):
    class Meta:
        model = StudentLogin
        fields = '__all__'


class StudentsSerializers(serializers.ModelSerializer):
    class Meta:
        model = Students
        fields = '__all__'


class BookSerializers(serializers.ModelSerializer):
    class Meta:
        model = Book
        fields = '__all__'


class BookInstanceSerializers(serializers.ModelSerializer):
    class Meta:
        model = BookInstance
        fields = '__all__'

 ### GET
class BookInstanceSerializersGET(serializers.ModelSerializer):
    class Meta:
        model = BookInstance
        fields = '__all__'
        depth = 10

class Book_IssueSerializers(serializers.ModelSerializer):
    class Meta:
        model = Book_Issue
        fields = '__all__'


class Book_IssueSerializersGET(serializers.ModelSerializer):
    class Meta:
        model = Book_Issue
        fields = '__all__'
        depth = 10


