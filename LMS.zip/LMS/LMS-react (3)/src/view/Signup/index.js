import React, { useState } from 'react';
import './style.scss'
import axios from 'axios';
import { Container, Row, Col, Button, Form } from 'react-bootstrap'
import { useNavigate } from 'react-router-dom';
import eyeIcon from './../../assets/Images/eye-slash.svg';
import Loginbanner from './../../assets/Images/signup-banner.png'
import Logo from '../../assets/Images/logo.png'
import emailIcon from './../../assets/Images/envelope.svg'
import Shields from './../../assets/Images/shield-slash.svg'
import userIcon from './../../assets/Images/person.svg';



const Signup = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [showPassword2, setShowPassword2] = useState(false);


  const handleTogglePasswordVisibility = () => {
    setShowPassword((prevState) => !prevState);
  };
  
  const handleTogglePasswordVisibility2 = () => {
    setShowPassword2((prevState) => !prevState);
  };
  

const [email, setEmail] = useState('');
const [password, setPassword] = useState('');
const [UserName, setUserName] = useState('');
const navigate = useNavigate();



const handleSubmit = (e) => {
  e.preventDefault();
  const requestData = {
    user_name: UserName,
    user_email: email,
    user_password: password
  };
  
  console.log(requestData);

  axios.post('http://127.0.0.1:8000/StudentLogin/', requestData)
    .then((response) => {
      alert("Sign up Successfully");
      navigate('/');
    })
    .catch((error) => {
      // console.log(requestData); 
      alert("User with this email already exists")
    });
};


 
  return (
    <div className='sign-up-main-wrapper'>
      <Container fluid className='p-0'>
        <Row className="g-0">
          <Col sm={12} md={6} lg={6} xl={6}>
            <div className="left-sec-wrap">
              <img src={Loginbanner} alt='banner' />
              <div className='bottom-title'>
                <h3>Join us!</h3>
                <p>Just go through the boring process of creating an account.</p>
              </div>
            </div>
          </Col>
          <Col sm={12} md={6} lg={6} xl={6}>
            <div className="right-login-section">
              <div className='logo-wrap'>
                <img src={Logo} alt='logo' />
              </div>
              <div className='login-title'>
                <h3>Create your account</h3>
                <p>Unlock all Features!</p>
              </div>
              <Form onSubmit={handleSubmit}>
                <Form.Group className="mb-3 position-relative" controlId="formBasicEmail1">
                  <Form.Control type="text" placeholder="Username" required  onChange={(e) => setUserName(e.target.value)} />
                  <img className='left-icons' src={userIcon} alt='username'/>
                </Form.Group>  
                <Form.Group className="mb-3 position-relative" controlId="formBasicEmail">
                  <Form.Control type="email" placeholder="Email" required  onChange={(e) => setEmail(e.target.value)} />
                  <img className='left-icons' src={emailIcon} alt='email'/>
                </Form.Group>
                <Form.Group className="mb-2 position-relative" controlId="formBasicPassword1">
                <Form.Control
                        type={showPassword ? 'text' : 'password'}
                        placeholder="Password"
                        value={password}
                        required
                        pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$"
                        title="Password must have at least 8 characters, including uppercase, lowercase, digits, and special characters."
                        onChange={(e) => setPassword(e.target.value)}
                      />
                  <img className='left-icons' src={Shields} alt='shield'/>
                  <img
                        className='eyes-icon'
                        src={eyeIcon}
                        alt='eyes'
                        onClick={handleTogglePasswordVisibility}
                      />
                </Form.Group>
                <Form.Group className="mb-2 position-relative" controlId="formBasicPassword">
                  <Form.Control type={showPassword2 ? 'text' : 'password'}  placeholder="Confirm Password" required  pattern={password} />
                  <img className='left-icons' src={Shields} alt='shield'/>
                  <img
                        className='eyes-icon'
                        src={eyeIcon}
                        alt='eyes'
                        onClick={handleTogglePasswordVisibility2}
                      />
                </Form.Group>
                <div className='remember-wrap'>
                   <Form.Group className="position-relative" controlId="formBasicCheckbox">
                      <Form.Check type="checkbox" label="Accept" required />
                    </Form.Group>
                    <a href='#/'>terms and conditions</a>
                </div>
                <Button className='login-btn' variant="primary" type="submit">
                  Sign Up
                </Button>
                <div className='create-account-wrap'>
                  <p>You have account? <a href='/'>Login now</a></p>
                </div>
              </Form>
            </div>
          </Col>
        </Row>
      </Container>
    </div>
  )
}

export default Signup