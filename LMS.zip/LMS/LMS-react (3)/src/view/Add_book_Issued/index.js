import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './style.scss'
import Select from 'react-select';
import { Container, Row, Col, Button, Form } from 'react-bootstrap'
import Header from './../../components/Header';

const AddIssueBook = () => {

  const [StudentData, setStudentData] = useState([]);
  const [BookData, setBookData] = useState([]);
  const [formData, setFormData] = useState({
    student: '',
    book_instance: ''
  });


  useEffect(() => {
    axios
      .get('http://localhost:8000/Students/')
      .then(response => {
        setStudentData(response.data.response);
      })
      .catch(error => {
        
      });
  
    axios
      .get('http://localhost:8000/BookGET/')
      .then(response => {
       
        setBookData(response.data.response);
      })
      .catch(error => {
        
        
      });
  }, []);




  const optionsStudent = StudentData.map(item => ({
    value: item.id,
    label: item.fullname,
  }));
  

  const handleChange = (selectedOption) => {
    setFormData({
      ...formData,
      student: selectedOption.value
    });
  };


  const options = BookData.map(item => ({
    value: item.id,
    label: item.book_title,
  }));



  const bookHandleChange = (selectedOption2) => {
    setFormData({
      ...formData,
      book_instance: selectedOption2.value
    });
  };



  const postData = {
    student: formData.student,
    book_instance: formData.book_instance
  };


  const handleSubmit = (event) => {
    setFormData({
      ...formData,
      [event.target.name]: event.target.value
    });




    //  Post Request handle 

    axios.post('http://localhost:8000/Book_Issue/', postData)
    .then((response) => {
      // Handle the successful login response
      alert("Book issued Sucessfully")
      
    })
    .catch((error) => {
      
      alert("Book issued Unsucessfully")
      console.log(error); // Example: display the error message
    });



  };

  


  return (
    <div className='add-issue-book-wrapper'>
      <Header />
      <Container fluid className='main-container-wrap'>
        <Row className="h-100 align-items-center justify-content-center">
          <Col>
            <div className="main-book-section">
              <div className='book-issued-title'>
                <h3>Enter Library Books Details</h3>
              </div>
              <Form onSubmit={handleSubmit} >
              <Form.Group className="mb-3" controlId="formBasicEmail">
              <Form.Label>Student Detail (Name)</Form.Label>
              <Select
                options={optionsStudent}
                isSearchable
                placeholder="Select an option"
                onChange={handleChange}
                styles={{
                  control: (provided) => ({
                    ...provided,
                    borderRadius: 1,
                  }),
                }}
              />
            </Form.Group>
                <Form.Group className="mb-3" controlId="formBasicEmail">
                  <Form.Label>Book Details</Form.Label>
                  <Select
                options={options}
                isSearchable
                placeholder="Select an option"
                onChange={bookHandleChange}
                styles={{
                  control: (provided) => ({
                    ...provided,
                    borderRadius: 1,
                  }),
                }}
              />
                </Form.Group>
                <Form.Group className="mb-3" controlId="formBasicEmail">
                  <Form.Label>Remarks</Form.Label>
                  <Form.Control type="text" value = "Good Conditions" />
                </Form.Group>
                <div className='issue-book-btn'>
                  <Button className='add-btn' variant="primary" type="submit">
                    Issue Book
                  </Button>
                </div>
              </Form>
            </div>
          </Col>
        </Row>
      </Container>
    </div>

  )
}

export default AddIssueBook