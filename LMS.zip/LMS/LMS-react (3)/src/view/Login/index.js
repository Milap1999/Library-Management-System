import React, { useState } from 'react';
import './style.scss';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { Container, Row, Col, Button, Form } from 'react-bootstrap';
import Loginbanner from './../../assets/Images/login-banner.png';
import Logo from '../../assets/Images/logo.png';
import emailIcon from './../../assets/Images/envelope.svg';
import eyeIcon from './../../assets/Images/eye-slash.svg';
import Shields from './../../assets/Images/shield-slash.svg';

const Login = ()=> {
  
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const handleTogglePasswordVisibility = () => {
    setShowPassword((prevState) => !prevState);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const requestData = {
      user_email: email,
      user_password: password
    };


    // Make the API request
    axios.post('http://127.0.0.1:8000/login/', requestData)
      .then((response) => {
        // Handle the successful login response
        let role = response.data.response.role; 
        if (role === "Admin") {
          navigate('/student');
        }
        if(role === "Student"){
            navigate('/Home');
        }
      })
      .catch((error) => {
        alert("Invaild Email or Password")
        // Handle the login error
        console.log(error); // Example: display the error message
      });
  };
  return (
    <div className='main-wrapper'>
      <Container fluid className='p-0'>
        <Row className="g-0">
          <Col sm={12} md={6} lg={6} xl={6}>
            <div className="left-sec-wrap">
              <img src={Loginbanner} alt='banner' />
              <div className='bottom-title'>
                <h3>Connect with any device.</h3>
                <p>Everything you need is an internet connection.</p>
              </div>
            </div>
          </Col>
          <Col sm={12} md={6} lg={6} xl={6}>
            <div className="right-login-section">
              <div className='logo-wrap'>
                <img src={Logo} alt='logo' />
              </div>
              <div className='login-title'>
                <h3>Login to your Account</h3>
                <p>Welcome back! </p>
              </div>
              <Form onSubmit={handleSubmit}>
                <Form.Group className="mb-3 position-relative" controlId="formBasicEmail">
                  <Form.Control type="email" placeholder="Email" value={email} required onChange={(e) => setEmail(e.target.value)} />
                  <img className='left-icons' src={emailIcon} alt='email'/>
                </Form.Group>

                <Form.Group className="mb-2 position-relative" controlId="formBasicPassword">
                <Form.Control
                          type={showPassword ? 'text' : 'password'}
                          placeholder="Password"
                          value={password}
                          required
                          onChange={(e) => setPassword(e.target.value)}
                        />
                  <img className='left-icons' src={Shields} alt='shield'/>
                  <img
                        className='eyes-icon'
                        src={eyeIcon}
                        alt='eyes'
                        onClick={handleTogglePasswordVisibility}
                      />
                </Form.Group>
                <div className='remember-wrap'>
                   <Form.Group className="position-relative" controlId="formBasicCheckbox">
                      <Form.Check type="checkbox" required label="Remember me" />
                    </Form.Group>
                    <a href='#/'>Forgot Password?</a>
                </div>
                <Button className='login-btn' variant="primary" type="submit">
                  Login
                </Button>
                <div className='create-account-wrap'>
                  <p>Don’t have account? <a href='/signup'>Create account</a></p>
                </div>
              </Form>
            </div>
          </Col>
        </Row>
      </Container>
    </div>
  )
}

export default Login;
