import "./style.scss";
import axios from "axios";
import React, { useEffect, useState } from "react";
import Header from "./../../components/Header";
import addIcon from "./../../assets/Images/Plus.svg";
import { Form, Table } from "react-bootstrap";
import editIcon from "./../../assets/Images/edit.svg";
import deleteIcon from "./../../assets/Images/delete.svg";
import AddStudent from "../../components/AddStudent";
import EditStudent from "../../components/EditStudent";

import { useNavigate } from "react-router-dom";

const Student = () => {
  // const [selectedItemId, setSelectedItemId] = useState(null);
  // const [modalShow, setModalShow] = useState(false);
  const [StudentID, setStudentID] = useState(null);
  const [rollNo, setRollno] = useState(null);
  const [fullname, setFullname] = useState(null);
  const [address, setAddress] = useState(null);
  const [program, setProgram] = useState(null);
  const [Guardian_name, setGurdian] = useState(null);
  const [Email, setEmail] = useState(null);

  const navigate = useNavigate();
  const [studentData, setStudentData] = useState([]); // Define the studentData variable using useState
  const [students, setStudents] = useState([]);






  useEffect(() => {
    axios
      .get("http://localhost:8000/Students/")
      .then((response) => {
        // Handle the successful response
        setStudentData(response.data.response); // Update the studentData using setStudentData
      })
      .catch((error) => {
        // Handle the error
        console.error(error);
      });
  }, []);

  useEffect(() => {
    // Fetch students data from API and set it in the state
    axios
      .get("http://localhost:8000/Students")
      .then((response) => {
        setStudents(response.data);
      })
      .catch((error) => {
        console.error("Error fetching students data:", error);
      });
  }, []);
  const handleDelete = (id) => {
    const apiUrl = `http://localhost:8000/Students/${id}`;
    axios
      .delete(apiUrl)
      .then((response) => {
        alert("Student deleted successfully");
        window.location.reload();
        navigate("/student");

        // Remove the deleted student from the state
        // setStudents((prevStudents) => prevStudents.filter((student) => student.id !== id));
      })
      .catch((error) => {
        console.error("Error sending DELETE request:", error);
      });
  };

  console.log(studentData);




 


  const showDeleteConfirmation = (id) => {
    const confirmed = window.confirm("Are you sure you want to delete?");
    if (confirmed) {
      handleDelete(id);
    }
  };
  const [modalShow, setModalShow] = useState(false);
  const [modalShow1, setModalShow1] = useState(false);



  const handleEditClick = (
    StudentID,
    rollNo,
    fullname,
    address,
    program,
    Guardian_name,
    Email
  ) => {
    
    setStudentID(StudentID)
    setRollno(rollNo)
    setFullname(fullname)
    setAddress(address)
    setProgram(program)
    setGurdian(Guardian_name)
    setEmail(Email)
    setModalShow1(true); ;
   
  };

  // const [modalShow, setModalShow] = useState(false);
  const initialFormData = {
    roll_number: '',
    fullname: '',
    address: '',
    program: '',
    guardian_name: '',
    email: '',
  };
  const [formData, setFormData] = useState(initialFormData);

  const handleCloseModal = () => {
    // setFormData(true)
    setModalShow(!modalShow); // Hide the modal
  };

  return (
    <div>
      {/* header */}
      {/* Header component goes here */}
      <Header />
      <div className="student-main-wrapper">
        <div className="card-wrap">
          <div className="student-table-header">
            {/* Search field */}
            <Form className="search-field">
              <Form.Group className="" controlId="formBasicEmail">
                <Form.Control type="text" placeholder="Search Student" />
              </Form.Group>
            </Form>
            {/* Add student button */}
            <button
              onClick={handleCloseModal}
              className="common-add-btn"
            >
              <img className="add-img" src={addIcon} alt="addicon" />
              Add Student
            </button>
          </div>
          <div className="student-table-wrap">
            {/* Student table */}
            <Table>
              <thead>
                <tr>
                  <th>Student Roll No</th>
                  <th>Student Name</th>
                  <th>Student Address</th>
                  <th>Student Study Program</th>
                  <th>Student Guardian/Parent</th>
                  <th>Guardian/Parent Email</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {studentData.map((student) => (
                  <tr key={student.id}>
                    <td>{student.roll_number}</td>
                    <td>{student.fullname}</td>
                    <td>{student.address}</td>
                    <td>{student.program}</td>
                    <td>{student.Guardian_name}</td>
                    <td>{student.Email}</td>
                    <td>
                      <div className="action-wrap">
                        <div className="common-btn-bg">
                          <button onClick={() => handleEditClick(
                            student.id,student.roll_number,student.fullname,student.address,student.program
                            ,student.Guardian_name,student.Email
                          )}>
                            <img src={editIcon} alt="edit" />
                          </button>
                        </div>
                        <div className="common-btn-bg">
                          <button
                            onClick={() => showDeleteConfirmation(student.id)}
                          >
                            <img src={deleteIcon} alt="delete" />
                          </button>
                        </div>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>
        </div>
      </div>
      {/* add student modal  */}
      <AddStudent
        show={modalShow}
        onHide={() => setModalShow(false)}
      />
     <EditStudent
        show={modalShow1}
        onHide={() => setModalShow(false)}
        onClick={() =>
        handleEditClick(
          StudentID,
          rollNo,
          fullname,
          address,
          program,
          Guardian_name,
          Email
        )
      }
      id={StudentID}
      roll_number={rollNo}
      fullname={fullname}
      address={address}
      program={program}
      Guardian_name={Guardian_name}
      Email={Email}
    />
    </div>
  );
};

export default Student;
