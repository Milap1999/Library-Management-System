import React, { useEffect, useState } from "react";
import "./style.scss";
import axios from "axios";
import Header from "./../../components/Header";
import { Table } from "react-bootstrap";
// import editIcon from './../../assets/Images/edit.svg';
import TickGreen from "./../../assets/Images/tick-green.svg";
import TickRed from "./../../assets/Images/tick-red.svg";
import ReturnRemarksModal from "./../../components/ReturnRemark";
// import rightArrow from './../../assets/Images/right-black.svg';
const BooksIssued = () => {
  const [showRemarksModal, setShowRemarksModal] = useState(false);
  const [selectedRemarks, setSelectedRemarks] = useState("");
  const [selectedItemId, setSelectedItemId] = useState(null);
  const [StudentID, setStudentID] = useState(null);
  const [BookID, setBookID] = useState(null);

  const handleYesClick = (remarks, itemId, StudentID, BookID) => {
    setSelectedRemarks(remarks);
    setSelectedItemId(itemId);
    setStudentID(StudentID);
    setBookID(BookID);
  };

  const [BooksData, setStudentData] = useState([]); // Define the studentData variable using useState

  useEffect(() => {
    axios
      .get("http://localhost:8000/Book_Issue/")
      .then((response) => {
        setStudentData(response.data.response); // Update the studentData using setStudentData
      })
      .catch((error) => {
        // Handle the error
      });
  }, []);

  return (
    <div>
      {/* header  */}
      <Header />
      <div className="booksissued-main-wrapper">
        <div className="card-wrap">
          <div className="books-table-header">
            <h3>Books Issued</h3>
          </div>
          <div className="booksissued-table-wrap">
            <Table>
              <thead>
                <tr>
                  <th>Student Name</th>
                  <th>
                    Book Name
                  </th>
                  <th>Issue Date</th>
                  <th>Due Date</th>
                  <th>Return Date Date</th>
                  <th>Remarks on Issuing</th>
                  <th>Remarks on return</th>
                  <th>Returned</th>
                  {/* <th>Action</th> */}
                </tr>
              </thead>
              <tbody>
                {BooksData.map((item) => (
                  <tr key={item.id}>
                    <td>{item.student.fullname}</td>
                    <td>{item.book_instance.book_title}</td>
                    <td>{item.issue_date}</td>
                    <td>{item.due_date}</td>
                    <td>
                      {item.date_returned === 'null'
                        ? "Not Returned"
                        : item.date_returned}
                    </td>
                    <td>{item.remarks_on_issue}</td>
                    <td>{item.remarks_on_return}</td>
                    <td>
                      {item.date_returned === "null" ? (
                        <div
                          className="tick-available"
                          style={{ cursor: "auto" }}
                        >
                          <button
                            onClick={() =>
                              handleYesClick(
                                item.remarks_on_return,
                                item.id,
                                item.student.id,
                                item.book_instance.id
                              )
                            }
                          >
                            <img
                              src={TickRed}
                              alt="tick"
                              onClick={() => setShowRemarksModal(true)}
                            />
                          </button>
                        </div>
                      ) : (
                        <div className="tick-available">
                          <button>
                            <img src={TickGreen} alt="tick" />
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
            <ReturnRemarksModal
              show={showRemarksModal}
              onHide={() => setShowRemarksModal(false)}
              onYesClick={(remarks, itemId, studentId, bookId) =>
                handleYesClick(remarks, itemId, studentId, bookId)
              } // Pass itemId to onYesClick
              selectedItemId={selectedItemId} // Pass selectedItemId to the modal
              studensID={StudentID}
              BookID={BookID}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default BooksIssued;
