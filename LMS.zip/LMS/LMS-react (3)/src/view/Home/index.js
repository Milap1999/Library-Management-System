import React from 'react'
import './style.scss'
import { Container, Row, Col, } from 'react-bootstrap'
import Footer from './../../components/Footer';
import bannerImg from './../../assets/Images/home-banner.png';
import rightArrow from '../../assets/Images/right-arrow.svg';
import { Splide, SplideSlide } from '@splidejs/react-splide';
import Book1 from './../../assets/Images/book1.jpg';
import Book2 from './../../assets/Images/book2.jpg';
import Book3 from './../../assets/Images/book3.jpg';
import Book4 from './../../assets/Images/book4.jpg';
import Book5 from './../../assets/Images/book5.jpg';
import Book6 from './../../assets/Images/book6.jpg';
import Book7 from './../../assets/Images/non-fiction/Etiquette by Emily Post.jpg';
import Book8 from './../../assets/Images/non-fiction/How to Use Your Mind by Harry Dexter Kitson.jpg';
import Book9 from './../../assets/Images/non-fiction/On the Origin of Species by Charles Darwin.jpg';
import Book10 from './../../assets/Images/non-fiction/The Age of Reason by D. J. Medley.jpg';
import Book11 from './../../assets/Images/non-fiction/The Communist Manifesto by Karl Marx_ Frederick Eng.jpg';
import Book12 from './../../assets/Images/non-fiction/The Demon Girl by Penelope Fletcher.jpg';
import Book13 from './../../assets/Images/action&adventure/_Tween Snow and Fire by Bertram Mitford.jpg';
import Book14 from './../../assets/Images/action&adventure/20_000 Leagues Under the Sea by Jules Verne.jpg';
import Book15 from './../../assets/Images/action&adventure/Adventures of Huckleberry Finn by Mark Twain.jpg';
import Book16 from './../../assets/Images/action&adventure/The Art of War by Zi Sun.jpg';
import Book17 from './../../assets/Images/action&adventure/The Call of the Wild by Jack London.jpg';
import Book18 from './../../assets/Images/action&adventure/The Count of Monte Cristo by Alexandre Dumas.jpg';
import Book19 from './../../assets/Images/romance/Emma by Jane Austen.jpg';
import Book20 from './../../assets/Images/romance/Healing Her Heart by Laura Scott.jpg';
import Book21 from './../../assets/Images/romance/Le Morte D_Arthur_ vol 1 by Sir Malory Thoma.jpg';
import Book22 from './../../assets/Images/romance/Pride and Prejudice by Jane Austen.jpg';
import Book23 from './../../assets/Images/romance/The Unveiling by Tamara Leigh.jpg';
import Book24 from './../../assets/Images/romance/Wuthering Heights by Emily Brontë.jpg';
import Book25 from './../../assets/Images/children/Are You There God_ It_s Me__y.jpg';
import Book26 from './../../assets/Images/children/Harry Potter and the Sorcerer_s_yyth.jpg';
import Book27 from './../../assets/Images/children/Mary Anne_s Bad Luck Mystery.jpg';
import Book28 from './../../assets/Images/children/The Deep End.jpg';
import Book29 from './../../assets/Images/children/The Lightning Thief.jpg';
import Book30 from './../../assets/Images/children/Twenty Thousand Fleas Under the_yyth.jpg';
import Book31 from './../../assets/Images/suspense/I Will Find You.jpg';
import Book32 from './../../assets/Images/suspense/Identity.jpg';
import Book33 from './../../assets/Images/suspense/The Boys from Biloxi.jpg';
import Book34 from './../../assets/Images/suspense/The Last Thing He Told Me.jpg';
import Book35 from './../../assets/Images/suspense/The Paris Apartment.jpg';
import Book36 from './../../assets/Images/suspense/Verity.jpg';
import { Nav, Navbar } from 'react-bootstrap';
import logo from './../../assets/Images/logo.png';
import Dropdown from 'react-bootstrap/Dropdown';
import profile from './../../assets/Images/user-avatar.jpg';
import './style.scss';
import { useNavigate } from 'react-router-dom';

// import { NavLink } from "react-router-dom";
// import { useNavigate } from 'react-router-dom';
import '@splidejs/react-splide/css';
const Home = () => {
  const navigate = useNavigate();

  return (
    <div className='main-home-layout'>
      <div>
        <Navbar collapseOnSelect expand="lg" bg="white">
          {/* <Container> */}
          <Navbar.Brand href="#/"><img src={logo} alt="logo" /></Navbar.Brand>
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse id="responsive-navbar-nav">
            {/* <Nav className="m-auto">
              <Nav.Link><NavLink to="/home">Home</NavLink></Nav.Link>
              <Nav.Link><NavLink to="/AddBookIssued">Add Issue Books</NavLink></Nav.Link>
              <Nav.Link><NavLink to="/student">Student</NavLink></Nav.Link>
              <Nav.Link><NavLink to="/books">Books</NavLink></Nav.Link>
              <Nav.Link><NavLink to="/bookissued">Books Issued</NavLink></Nav.Link>
            </Nav> */}
            <Nav style={{ display: 'flex', justifyContent: 'flex-end' }}>
              <Dropdown className="profile-wrap" style={{ position: 'absolute', top: '5px', right: '10px' }}>
                <Dropdown.Toggle id="dropdown-basic">
                  <img src={profile} alt="profile" />
                </Dropdown.Toggle>

                <Dropdown.Menu style={{ right: 0, left: 'auto' }}>
                  <Dropdown.Item href="#/action-1">Profile</Dropdown.Item>
                  <Dropdown.Item href="#/action-2">Setting</Dropdown.Item>
                  <Dropdown.Item onClick={() => navigate('/')}>Logout</Dropdown.Item>
                </Dropdown.Menu>
              </Dropdown>

            </Nav>
          </Navbar.Collapse>
          {/* </Container> */}
        </Navbar>
      </div>
      {/* header */}
      {/* <Header /> */}
      <Container fluid className="home-wrapper">
        <Row>
          <Col sm={6} md={6} lg={6} xl={6}>
            <div className='left-banner-details'>
              <h3>Library Management <span>system</span></h3>
              <h6>Nothing is pleasanter than exploring a library.</h6>
              <button className='get-started-btn'>Get Started <img src={rightArrow} alt="arrow" /></button>
            </div>
          </Col>
          <Col sm={6} md={6} lg={6} xl={6}>
            <div className='right-banner-img'>
              <img src={bannerImg} alt="banner" />
            </div>
          </Col>
        </Row>
      </Container>
      <section className='books-slider-wrap'>
        <div className='books-category-wrap'>
          <h3 className='book-title'>Trending</h3>
          <Splide
            options={{
              perPage: 6,
              rewind: true,
              gap: '10px',
              autoplay: true,
            }}
            aria-labelledby="basic-example-heading"
            onMoved={(splide, newIndex) => {
            }}
          >
            {/* {generateSlides().map(slide => (
              <SplideSlide key={slide.src}>
                <img src={slide.src} alt={slide.alt} />
              </SplideSlide>
            ))} */}
            <SplideSlide>
              <a target='blank' href="/uploads/media/default/0001/01/540cb75550adf33f281f29132dddd14fded85bfc.pdf">
                <img src={Book1} alt={"slide"} />
                <h4 className='book-name'>David Elginbrod</h4>
              </a>
            </SplideSlide>
            <SplideSlide>
              <img src={Book2} alt={"slide"} />
              <h4 className='book-name'>Lay Down Your Arms</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book3} alt={"slide"} />
              <h4 className='book-name'>In the teeth of the evidence</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book4} alt={"slide"} />
              <h4 className='book-name'>Burmese Days</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book5} alt={"slide"} />
              <h4 className='book-name'>A message to garcia</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book6} alt={"slide"} />
              <h4 className='book-name'>The Debacle</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book1} alt={"slide"} />
              <h4 className='book-name'>Dummy lorem</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book1} alt={"slide"} />
              <h4 className='book-name'>Dummy lorem</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book2} alt={"slide"} />
              <h4 className='book-name'>Dummy lorem</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book3} alt={"slide"} />
              <h4 className='book-name'>Dummy lorem</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book4} alt={"slide"} />
              <h4 className='book-name'>Dummy lorem</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book5} alt={"slide"} />
              <h4 className='book-name'>Dummy lorem</h4>
            </SplideSlide>
          </Splide>
        </div>
        <div className='books-category-wrap'>
          <h3 className='book-title'>Non-Fiction</h3>
          <Splide
            options={{
              perPage: 6,
              rewind: true,
              gap: '10px',
              autoplay: true,
            }}
            aria-labelledby="basic-example-heading"
            onMoved={(splide, newIndex) => {
            }}
          >
            {/* {generateSlides().map(slide => (
              <SplideSlide key={slide.src}>
                <img src={slide.src} alt={slide.alt} />
              </SplideSlide>
            ))} */}
            <SplideSlide>
              <a target='blank' href="/uploads/media/default/0001/01/540cb75550adf33f281f29132dddd14fded85bfc.pdf">
                <img src={Book7} alt={"slide"} />
                <h4 className='book-name'>Etiquette by Emily Post</h4>
              </a>
            </SplideSlide>
            <SplideSlide>
              <img src={Book8} alt={"slide"} />
              <h4 className='book-name'>How to Use Your Mind by Harry Dexter Kitson</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book9} alt={"slide"} />
              <h4 className='book-name'>On the Origin of Species by Charles Darwin</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book10} alt={"slide"} />
              <h4 className='book-name'>The Age of Reason by D. J. Medley</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book11} alt={"slide"} />
              <h4 className='book-name'>The Communist Manifesto by Karl Marx_ Frederick Eng</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book12} alt={"slide"} />
              <h4 className='book-name'>The Demon Girl by Penelope Fletcher</h4>
            </SplideSlide>
            <SplideSlide>
              <a target='blank' href="/uploads/media/default/0001/01/540cb75550adf33f281f29132dddd14fded85bfc.pdf">
                <img src={Book7} alt={"slide"} />
                <h4 className='book-name'>Etiquette by Emily Post</h4>
              </a>
            </SplideSlide>
            <SplideSlide>
              <img src={Book8} alt={"slide"} />
              <h4 className='book-name'>How to Use Your Mind by Harry Dexter Kitson</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book9} alt={"slide"} />
              <h4 className='book-name'>On the Origin of Species by Charles Darwin</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book10} alt={"slide"} />
              <h4 className='book-name'>The Age of Reason by D. J. Medley</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book11} alt={"slide"} />
              <h4 className='book-name'>The Communist Manifesto by Karl Marx_ Frederick Eng</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book12} alt={"slide"} />
              <h4 className='book-name'>The Demon Girl by Penelope Fletcher</h4>
            </SplideSlide>
          </Splide>
        </div>
        <div className='books-category-wrap'>
          <h3 className='book-title'>Action & Adventure</h3>
          <Splide
            options={{
              perPage: 6,
              rewind: true,
              gap: '10px',
              autoplay: true,
            }}
            aria-labelledby="basic-example-heading"
            onMoved={(splide, newIndex) => {
            }}
          >
            {/* {generateSlides().map(slide => (
              <SplideSlide key={slide.src}>
                <img src={slide.src} alt={slide.alt} />
              </SplideSlide>
            ))} */}
            <SplideSlide>
              <a target='blank' href="/uploads/media/default/0001/01/540cb75550adf33f281f29132dddd14fded85bfc.pdf">
                <img src={Book13} alt={"slide"} />
                <h4 className='book-name'>_Tween Snow and Fire by Bertram Mitford.jpg</h4>
              </a>
            </SplideSlide>
            <SplideSlide>
              <img src={Book14} alt={"slide"} />
              <h4 className='book-name'>20_000 Leagues Under the Sea by Jules Verne</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book15} alt={"slide"} />
              <h4 className='book-name'>Adventures of Huckleberry Finn by Mark Twain</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book16} alt={"slide"} />
              <h4 className='book-name'>The Art of War by Zi Sun.jpg</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book17} alt={"slide"} />
              <h4 className='book-name'>The Call of the Wild by Jack London</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book18} alt={"slide"} />
              <h4 className='book-name'>The Count of Monte Cristo by Alexandre Dumas.jpg</h4>
            </SplideSlide>
            <SplideSlide>
              <a target='blank' href="/uploads/media/default/0001/01/540cb75550adf33f281f29132dddd14fded85bfc.pdf">
                <img src={Book13} alt={"slide"} />
                <h4 className='book-name'>_Tween Snow and Fire by Bertram Mitford.jpg</h4>
              </a>
            </SplideSlide>
            <SplideSlide>
              <img src={Book14} alt={"slide"} />
              <h4 className='book-name'>20_000 Leagues Under the Sea by Jules Verne</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book15} alt={"slide"} />
              <h4 className='book-name'>Adventures of Huckleberry Finn by Mark Twain</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book16} alt={"slide"} />
              <h4 className='book-name'>The Art of War by Zi Sun.jpg</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book17} alt={"slide"} />
              <h4 className='book-name'>The Call of the Wild by Jack London</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book18} alt={"slide"} />
              <h4 className='book-name'>The Count of Monte Cristo by Alexandre Dumas.jpg</h4>
            </SplideSlide>
          </Splide>
        </div>
        <div className='books-category-wrap'>
          <h3 className='book-title'>Romance</h3>
          <Splide
            options={{
              perPage: 6,
              rewind: true,
              gap: '10px',
              autoplay: true,
            }}
            aria-labelledby="basic-example-heading"
            onMoved={(splide, newIndex) => {
            }}
          >
            {/* {generateSlides().map(slide => (
              <SplideSlide key={slide.src}>
                <img src={slide.src} alt={slide.alt} />
              </SplideSlide>
            ))} */}
            <SplideSlide>
              <a target='blank' href="/uploads/media/default/0001/01/540cb75550adf33f281f29132dddd14fded85bfc.pdf">
                <img src={Book19} alt={"slide"} />
                <h4 className='book-name'>Emma by Jane Austen</h4>
              </a>
            </SplideSlide>
            <SplideSlide>
              <img src={Book20} alt={"slide"} />
              <h4 className='book-name'>Healing Her Heart by Laura Scott</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book21} alt={"slide"} />
              <h4 className='book-name'>Le Morte D_Arthur_ vol 1 by Sir Malory Thoma</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book22} alt={"slide"} />
              <h4 className='book-name'>Pride and Prejudice by Jane Austen</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book23} alt={"slide"} />
              <h4 className='book-name'>The Unveiling by Tamara Leigh</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book24} alt={"slide"} />
              <h4 className='book-name'>Wuthering Heights by Emily Brontë</h4>
            </SplideSlide>
            <SplideSlide>
              <a target='blank' href="/uploads/media/default/0001/01/540cb75550adf33f281f29132dddd14fded85bfc.pdf">
                <img src={Book19} alt={"slide"} />
                <h4 className='book-name'>Emma by Jane Austen</h4>
              </a>
            </SplideSlide>
            <SplideSlide>
              <img src={Book20} alt={"slide"} />
              <h4 className='book-name'>Healing Her Heart by Laura Scott</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book21} alt={"slide"} />
              <h4 className='book-name'>Le Morte D_Arthur_ vol 1 by Sir Malory Thoma</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book22} alt={"slide"} />
              <h4 className='book-name'>Pride and Prejudice by Jane Austen</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book23} alt={"slide"} />
              <h4 className='book-name'>The Unveiling by Tamara Leigh</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book24} alt={"slide"} />
              <h4 className='book-name'>Wuthering Heights by Emily Brontë</h4>
            </SplideSlide>
          </Splide>
        </div>
        <div className='books-category-wrap'>
          <h3 className='book-title'>Children</h3>
          <Splide
            options={{
              perPage: 6,
              rewind: true,
              gap: '10px',
              autoplay: true,
            }}
            aria-labelledby="basic-example-heading"
            onMoved={(splide, newIndex) => {
            }}
          >
            {/* {generateSlides().map(slide => (
              <SplideSlide key={slide.src}>
                <img src={slide.src} alt={slide.alt} />
              </SplideSlide>
            ))} */}
            <SplideSlide>
              <a target='blank' href="/uploads/media/default/0001/01/540cb75550adf33f281f29132dddd14fded85bfc.pdf">
                <img src={Book25} alt={"slide"} />
                <h4 className='book-name'>Are You There God_ It_s Me__y</h4>
              </a>
            </SplideSlide>
            <SplideSlide>
              <img src={Book26} alt={"slide"} />
              <h4 className='book-name'>Harry Potter and the Sorcerer_s_yyth</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book27} alt={"slide"} />
              <h4 className='book-name'>Mary Anne_s Bad Luck Mystery</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book28} alt={"slide"} />
              <h4 className='book-name'>The Deep End</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book29} alt={"slide"} />
              <h4 className='book-name'>The Lightning Thief</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book30} alt={"slide"} />
              <h4 className='book-name'>Twenty Thousand Fleas Under the_yyth</h4>
            </SplideSlide>
            <SplideSlide>
              <a target='blank' href="/uploads/media/default/0001/01/540cb75550adf33f281f29132dddd14fded85bfc.pdf">
                <img src={Book25} alt={"slide"} />
                <h4 className='book-name'>Are You There God_ It_s Me__y</h4>
              </a>
            </SplideSlide>
            <SplideSlide>
              <img src={Book26} alt={"slide"} />
              <h4 className='book-name'>Harry Potter and the Sorcerer_s_yyth</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book27} alt={"slide"} />
              <h4 className='book-name'>Mary Anne_s Bad Luck Mystery</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book28} alt={"slide"} />
              <h4 className='book-name'>The Deep End</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book29} alt={"slide"} />
              <h4 className='book-name'>The Lightning Thief</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book30} alt={"slide"} />
              <h4 className='book-name'>Twenty Thousand Fleas Under the_yyth</h4>
            </SplideSlide>
          </Splide>
        </div>
        <div className='books-category-wrap'>
          <h3 className='book-title'>Suspence</h3>
          <Splide
            options={{
              perPage: 6,
              rewind: true,
              gap: '10px',
              autoplay: true,
            }}
            aria-labelledby="basic-example-heading"
            onMoved={(splide, newIndex) => {
            }}
          >
            {/* {generateSlides().map(slide => (
              <SplideSlide key={slide.src}>
                <img src={slide.src} alt={slide.alt} />
              </SplideSlide>
            ))} */}
            <SplideSlide>
              <a target='blank' href="/uploads/media/default/0001/01/540cb75550adf33f281f29132dddd14fded85bfc.pdf">
                <img src={Book31} alt={"slide"} />
                <h4 className='book-name'>I Will Find You</h4>
              </a>
            </SplideSlide>
            <SplideSlide>
              <img src={Book32} alt={"slide"} />
              <h4 className='book-name'>Identity</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book33} alt={"slide"} />
              <h4 className='book-name'>The Boys from Biloxi</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book34} alt={"slide"} />
              <h4 className='book-name'>The Last Thing He Told Me</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book35} alt={"slide"} />
              <h4 className='book-name'>The Paris Apartment</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book36} alt={"slide"} />
              <h4 className='book-name'>Verity</h4>
            </SplideSlide>
            <SplideSlide>
              <a target='blank' href="/uploads/media/default/0001/01/540cb75550adf33f281f29132dddd14fded85bfc.pdf">
                <img src={Book31} alt={"slide"} />
                <h4 className='book-name'>I Will Find You</h4>
              </a>
            </SplideSlide>
            <SplideSlide>
              <img src={Book32} alt={"slide"} />
              <h4 className='book-name'>Identity</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book33} alt={"slide"} />
              <h4 className='book-name'>The Boys from Biloxi</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book34} alt={"slide"} />
              <h4 className='book-name'>The Last Thing He Told Me</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book35} alt={"slide"} />
              <h4 className='book-name'>The Paris Apartment</h4>
            </SplideSlide>
            <SplideSlide>
              <img src={Book36} alt={"slide"} />
              <h4 className='book-name'>Verity</h4>
            </SplideSlide>
          </Splide>
        </div>
      </section>
      <Footer/>
    </div>
  )
}

export default Home