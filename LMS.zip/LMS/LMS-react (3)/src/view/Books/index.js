import React, { useEffect, useState } from 'react';
import './style.scss'
import axios from 'axios';
import Header from './../../components/Header';
import addIcon from './../../assets/Images/Plus.svg'
import { Form, Table } from 'react-bootstrap';
import editIcon from './../../assets/Images/edit.svg';
import deleteIcon from './../../assets/Images/delete.svg';
import AddBooksModal from './../../components/Add Books';
import EditBooksModal from './../../components/EditBooks';
import { useNavigate } from 'react-router-dom';


const Books = () => {
  const [bookData, setBookData] = useState([]);
  const [id, setBookID] = useState(null);
  const [book_title, setBookTitle] = useState(null);
  const [book_author, setBookAuthor] = useState(null);
  const [book_pages, setBookPage] = useState(null);
  const [summary, setBookSummary] = useState(null);
  const [is_Available, setBookAvailable] = useState(null);
  const handleEditClick = (
    id,
    book_title,
    book_author,
    book_pages,
    summary,
    is_Available,
  ) => {
    
    setBookID(id)
    setBookTitle(book_title)
    setBookAuthor(book_author)
    setBookPage(book_pages)
    setBookSummary(summary)
    setBookAvailable(is_Available)
    setModalShow1(true);
  };


  const navigate = useNavigate();


  useEffect(() => {
    axios
      .get('http://localhost:8000/Book/')
      .then(response => {
        setBookData(response.data.response);
      })
      .catch(error => {
        console.error(error);
      });
  }, []);

  console.log(bookData);



  const handleDelete = (id) => {
    const apiUrl = `http://localhost:8000/Book/${id}`;
    axios.delete(apiUrl)
    .then((response) => {
      alert('Book deleted successfully');
      window.location.reload();
      navigate('/books');

      // Remove the deleted student from the state
      // setStudents((prevStudents) => prevStudents.filter((student) => student.id !== id));
    })
    .catch((error) => {
      console.error('Error sending DELETE request:', error);
    });
  };
  const showDeleteConfirmation = (id) => {
    const confirmed = window.confirm('Are you sure you want to delete?');
    if (confirmed) {
      handleDelete(id);
    }
  };




  let serialNumber =1;


  const [modalShow, setModalShow] = React.useState(false);
  const [modalShow1, setModalShow1] = React.useState(true);


  return (
    <div>
      {/* header */}
      <Header />
      <div className='books-main-wrapper'>
        <div className='card-wrap'>
          <div className='books-table-header'>
            <Form className='search-field'>
              <Form.Group className='' controlId='formBasicEmail'>
                <Form.Control type='text' placeholder='Search Book' />
              </Form.Group>
            </Form>
            <button onClick={() => {setModalShow(!modalShow);}} className='common-add-btn'>
              <img className='add-img' src={addIcon} alt='addicon' />
              Add Book
            </button>
          </div>
          <div className='books-table-wrap'>
            <Table>
              <thead>
                <tr>
                  <th>Book ID</th>
                  <th>Book Title</th>
                  <th>Book Author</th>
                  <th>Book Pages</th>
                  <th>Book Summary</th>
                  <th>Is Available</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {bookData.map(book => (
                  <tr key={book.id}>
                    {/* <td>{book.id}</td> */}
                    <td>{serialNumber++}</td>
                    <td>{book.book_title}</td>
                    <td>{book.book_author}</td>
                    <td>{book.book_pages}</td>
                    <td>{book.summary}</td>
                    <td>{book.is_Available}</td>
                    <td>
                      <div className='action-wrap'>
                        <div className='common-btn-bg'>
                        <button onClick={() => handleEditClick(
                            book.id,book.book_title,book.book_author,book.book_pages,book.summary,
                            book.is_Available
                          )}>
                            <img src={editIcon} alt='edit' />
                          </button>
                        </div>
                        <div className='common-btn-bg'>
                        <button onClick={() => showDeleteConfirmation(book.id)}>
                            <img src={deleteIcon} alt='delete' />
                          </button>
                        </div>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>
        </div>
      </div>
      {/* add books modal */}
      <AddBooksModal
        show={modalShow}
        onHide={() => setModalShow(false)}
      />
      <EditBooksModal

        show={modalShow1}
        onHide={() => setModalShow1(false)}
        onClick={() =>
          handleEditClick(
            id,
            book_title,
            book_author,
            book_pages,
            summary,
            is_Available,
          )
        }
        id={id}
        book_title={book_title}
        book_author={book_author}
        book_pages={book_pages}
        summary={summary}
        is_Available={is_Available}


      />
    </div>
  );
};

export default Books;