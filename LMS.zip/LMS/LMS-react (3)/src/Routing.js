import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from './../src/view/Login';
import Signup from './../src/view/Signup';
import Home from './../src/view/Home';
import Student from "./view/Students";
import Books from "./view/Books";
import BooksIssued from "./view/Books_Issued";
import AddBookIssued from "./view/Add_book_Issued";
// import Attendance from "./view/Attendance";


const Routing = () => {
  return (
    <BrowserRouter> 
      <Routes>
      <Route path="/" element={<Login />} />
       <Route path="/signup" element={<Signup />} />
        <Route path="/home" element={<Home/>} />
        <Route path="/student" element={<Student/>} />
        <Route path="/books" element={<Books/>} />
        <Route path="/bookissued" element={<BooksIssued/>} />
        <Route path="/AddBookIssued" element={<AddBookIssued/>} />
        {/* <Route path="/attendace" element={<Attendance/>} /> */}


      </Routes>
    </BrowserRouter>
  );
};

export default Routing;
