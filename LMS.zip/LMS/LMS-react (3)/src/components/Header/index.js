import React from 'react'
import { Nav, Navbar, Container } from 'react-bootstrap';
import logo from './../../assets/Images/logo.png';
import Dropdown from 'react-bootstrap/Dropdown';
import profile from './../../assets/Images/user-avatar.jpg';
import './style.scss';
import { NavLink } from "react-router-dom";
import { useNavigate } from 'react-router-dom';

const Header = () => {
  const navigate = useNavigate();

  
  return (
    <div>
      <Navbar collapseOnSelect expand="lg" bg="white">
        <Container>
          <Navbar.Brand href="#/"><img src={logo} alt="logo" /></Navbar.Brand>
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse id="responsive-navbar-nav">
            <Nav className="m-auto">
              {/* <Nav.Link><NavLink to="/home">Home</NavLink></Nav.Link> */}
              <Nav.Link><NavLink to="/AddBookIssued">Add Issue Books</NavLink></Nav.Link>
              <Nav.Link><NavLink to="/student">Student</NavLink></Nav.Link>
              <Nav.Link><NavLink to="/books">Books</NavLink></Nav.Link>
              <Nav.Link><NavLink to="/bookissued">Books Issued</NavLink></Nav.Link>
              {/* <Nav.Link><NavLink to="/attendace">attendace</NavLink></Nav.Link> */}

            </Nav>
            <Nav>
                <Dropdown className="profile-wrap">
                  <Dropdown.Toggle id="dropdown-basic">
                     <img src={profile} alt="profile"/>
                  </Dropdown.Toggle>

                  <Dropdown.Menu>
                    <Dropdown.Item href="#/action-1">Profile</Dropdown.Item>
                    {/* <Dropdown.Item href="#/action-2">Setting</Dropdown.Item> */}
                    <Dropdown.Item  onClick={() => navigate('/')}>Logout</Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>
             
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    </div>
  )
}

export default Header