import React ,{ useState,useEffect } from 'react'
import './style.scss'
import { Modal, Button, Container, Col, Row, Form, Tab, Tabs } from 'react-bootstrap'
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import Select from 'react-select';



const EditBooksModal = (props) => {
  const {
    id,
    book_title,
    book_author,
    book_pages,
    summary,
    is_Available,
  } = props;
  console.log(id,
    book_title,
    book_author,
    book_pages,
    summary,
    is_Available,)
    const navigate = useNavigate();
    const [BookData, setBookData] = useState([]);
    const [selectedBook, setSelectedBook] = useState([]);
    const [bookNumber, setBookNumber] = useState('');
    useEffect(() => {
      setFormData({
        book_title: book_title || '',
        book_pages: book_pages || '',
        book_author: book_author || '',
        summary: summary || '',
      });
    }, [book_title, book_pages, book_author, summary]);

    useEffect(() => {
      
        axios
          .get('http://localhost:8000/Book/')
          .then(response => {
            setBookData(response.data.response);
           

          })
          .catch(error => {
            console.error(error);
          });
      }, []);
    
    const options = BookData.map(item => ({
        value: item.id,
        label: item.book_title,
      }));

      const BrrowhandleChange = (e) => {
        const { name, value, type, checked } = e.target;
        const newValue = type === 'checkbox' ? checked : value;
        setFormData((prevFormData) => ({
          ...prevFormData,
          [name]: newValue,
        }));
      };


    const [formData, setFormData] = useState({
        book_title: '',
        book_pages: '',
        book_author: '',
        summary: '',
      });
    
      const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevFormData) => ({
          ...prevFormData,
          [name]: value,
        }));
      };
    


      const bookHandleChange = (selectedOption2) => {
        setSelectedBook({
        ...formData,
        book_instance: selectedOption2.value
        });
    };
    
      const handleSubmit2 = (e) => {
        e.preventDefault();
        const apiUrl = 'http://localhost:8000/BookInstance/';

        const requestObj = {
         
            book_number: bookNumber,
            Is_borrowed:formData.isBorrowed,
            book: selectedBook.book_instance,
       
        };
    
        // Send the POST request using axios
        axios.post(apiUrl, requestObj)
          .then((response) => {
            alert("Book Added Successfully");
            window.location.reload();
            navigate('/books');

            // Clear the form fields after successful submission
            setFormData({
                book_number: bookNumber,
                Is_borrowed: false,
                book: selectedBook.book_instance,
            });
          })
          .catch((error) => {
            console.error('Error sending POST request:', error);
          });
      };

      const handleSubmit = (e) => {
        e.preventDefault();
        const apiUrl = `http://localhost:8000/Book/${id}`;
    
        // Create the request object from form data
        const requestObj = {
         
          book_title: formData.book_title,
          book_author: formData.book_author,
          book_pages: formData.book_pages,
          is_Available: "Yes", // Assuming it's always "Yes" for a new book
          summary: formData.summary,
        };
    
        // Send the POST request using axios
        axios.put(apiUrl, requestObj)
          .then((response) => {
            alert("Book Updated Successfully");
            console.log('PUT request successful:', response);
            window.location.reload();
            navigate('/books');
            // Clear the form fields after successful submission
            setFormData({
              book_title: '',
              book_pages: '',
              book_author: '',
              summary: '',
            });
          })
          .catch((error) => {
            console.error('Error sending POST request:', error);
          });
      };

    return (
        <div>
            <Modal
                {...props}
                size="lg"
                aria-labelledby="contained-modal-title-vcenter"
                centered
                className="add-book-modal-wrap"
            >
                <Modal.Header >
                    <Modal.Title id="contained-modal-title-vcenter">
                        Add Books
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Container fluid className='main-container-bg'>
                        <Tabs
                            defaultActiveKey="home"
                            id="uncontrolled-tab-example"
                            className=""
                        >
                            <Tab eventKey="home" title="New Book">
                                <Form className='forms-detail'>
                                    <Row>
                                    <Col sm={12} md={6} lg={6} xl={6}>
                                            <Form.Group className="mb-3" controlId="formBasicEmail">
                                            <Form.Label>Book Title</Form.Label>
                                            <Form.Control
                                                type="text"
                                                name="book_title"
                                                value={formData.book_title}
                                                onChange={handleChange}
                                                placeholder="Enter Book Title"
                                            />
                                            </Form.Group>
                                        </Col>
                                        <Col sm={12} md={6} lg={6} xl={6}>
                                            <Form.Group className="mb-3" controlId="formBasicEmail">
                                            <Form.Label>Book Pages</Form.Label>
                                            <Form.Control
                                                type="number"
                                                name="book_pages"
                                                value={formData.book_pages}
                                                onChange={handleChange}
                                                placeholder="Enter Book Pages"
                                            />
                                            </Form.Group>
                                        </Col>
                                        <Col sm={12} md={12} lg={12} xl={12}>
                                            <Form.Group className="mb-3" controlId="formBasicEmail">
                                            <Form.Label>Book Author</Form.Label>
                                            <Form.Control
                                                type="text"
                                                name="book_author"
                                                value={formData.book_author}
                                                onChange={handleChange}
                                                placeholder="Enter Book Author"
                                            />
                                            </Form.Group>
                                        </Col>
                                        <Col sm={12} md={12} lg={12} xl={12}>
                                            <Form.Group className="mb-3" controlId="formBasicEmail">
                                            <Form.Label>Book Summary(if any)</Form.Label>
                                            <Form.Control
                                                style={{ height: "150px" }}
                                                as="textarea"
                                                name="summary"
                                                value={formData.summary}
                                                onChange={handleChange}
                                                rows={1}
                                            />
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <div className='add-book-btn'>
                                        <Button className="add-btn" onClick={handleSubmit}>Add Book</Button>
                                    </div>
                                </Form>
                            </Tab>
                            <Tab eventKey="profile" title="Book Borrowed">
                                <Form className='forms-detail'>
                                    <Row>
                                        <Col sm={12} md={12} lg={12} xl={12}>
                                            <Form.Group className="mb-3" controlId="formBasicEmail">
                                                <Form.Label>Book List</Form.Label>
                                                <Select
                                                    options={options}
                                                    // value={selectedBook} 
                                                    isSearchable
                                                    placeholder="Select an option"
                                                      onChange={bookHandleChange}
                                                    styles={{
                                                    control: (provided) => ({
                                                        ...provided,
                                                        borderRadius: 1,
                                                    }),
                                                    }}
                                                />
                                            </Form.Group>
                                            <Form.Group className="mb-3" controlId="formBasicEmail">
                                                <Form.Label>Book Number</Form.Label>
                                                <Form.Control
                                                        type="number"
                                                        placeholder="Enter Book Number"
                                                        value={bookNumber}
                                                        onChange={(e) => setBookNumber(e.target.value)}
                                                    />
                                            </Form.Group>
                                            <Form.Group className="mb-3" controlId="formBasicEmail">
                                            <Form.Check
                                                    type="checkbox"
                                                    name="isBorrowed"
                                                    checked={formData.isBorrowed}
                                                    onChange={BrrowhandleChange}
                                                    label="Is borrowed"
                                                />
                                            </Form.Group>
                                        </Col>
                                    </Row>
                                    <div className='add-book-btn'>
                                        <Button className="add-btn" onClick={handleSubmit2}>Book issued</Button>
                                    </div>
                                </Form>
                            </Tab>
                        </Tabs>
                    </Container>
                </Modal.Body>
            </Modal>
        </div>
    )
}

export default EditBooksModal