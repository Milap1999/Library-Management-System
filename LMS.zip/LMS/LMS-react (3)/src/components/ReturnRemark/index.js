import React, { useState } from 'react';
import { Modal, Button, Form } from 'react-bootstrap';
import { format } from 'date-fns';
import axios from 'axios'; // Import axios
import { useNavigate } from 'react-router-dom';


const ReturnRemarksModal = ({ show, onHide, onYesClick, selectedItemId ,studensID, BookID }) => {
  const [remarks, setRemarks] = useState('');
  const currentDate = format(new Date(), "HH:mm dd/MM/yy");
  const navigate = useNavigate();








  const handleYesClick = () => {
    onYesClick(remarks, selectedItemId,studensID,BookID);
    onHide();
    // Perform the API call here when the user clicks "Yes"
    const apiUrl = `http://localhost:8000/Book_Issue/${selectedItemId}`;
    const requestData = {
      student:studensID,
      remarks_on_return: remarks,
      date_returned: currentDate,
      book_instance:BookID
    };
    console.log(requestData)
    axios.put(apiUrl, requestData)
      .then((response) => {
        alert("Book return successfully")
        window.location.reload();
        navigate('/bookissued')
        
        // Handle the response as needed
      })
      .catch((error) => {
        console.log(error);
        // Handle the error if the API request fails
      });
    // onYesClick(remarks);
    onHide();
  };

  return (
    <Modal show={show} onHide={onHide} centered>
      <Modal.Header closeButton>
        <Modal.Title>Remark on return</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form.Control
          type="text"
          placeholder="Enter remarks on return"
          value={remarks}
          onChange={(e) => setRemarks(e.target.value)}
        />
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={onHide}>
          No
        </Button>
        <Button variant="primary" onClick={handleYesClick}>
          Yes
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default ReturnRemarksModal;
