import React ,{ useState } from 'react'
import './style.scss'
import { Modal, Button, Container, Col, Row,Form } from 'react-bootstrap'
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
const AddStudent = (props) => {

 
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        roll_number: '',
        fullname: '',
        address: '',
        program: '',
        guardian_name: '',
        email: '',
      });
    const [students, setStudents] = useState([]);
    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevFormData) => ({
          ...prevFormData,
          [name]: value,
        }));
      };
      const handleSubmit = (e) => {
        e.preventDefault();
        const apiUrl = 'http://localhost:8000/Students/';
    
        // Create the request object from form data
        const requestObj = {
        //   id: 2,
          roll_number: formData.roll_number,
          fullname: formData.fullname,
          address: formData.address,
          program: formData.program,
          Guardian_name: formData.guardian_name,
          Email: formData.email,
        };
        
    
        // Send the POST request using axios
        axios.post(apiUrl, requestObj)
          .then((response) => {
            alert("Students Added Successful")
            window.location.reload();
            navigate('/student');
            setStudents((prevStudents) => [...prevStudents, response.data]);
            console.log('POST request successful:', response);
          })
          .catch((error) => {
            // Handle error if needed
            console.error('Error sending POST request:', error);
          });
      };



    return (
        <div>
            <Modal
                {...props}
                size="lg"
                aria-labelledby="contained-modal-title-vcenter"
                centered
                className='add-student-modal'
            >
                <Modal.Header closeButton>
                    <Modal.Title id="contained-modal-title-vcenter">
                        Add Student
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Container fluid className='main-container-bg'>
                        <div className='title-wrap'>
                           <h3>Student Details</h3>
                         </div>
                        <Form className='forms-detail'>
                            <Row>
                                <Col sm={12} md={6} lg={6} xl={6}>
                                <Form.Group className="mb-3" controlId="formRollNumber">
                                <Form.Label>Roll Number</Form.Label>
                                <Form.Control
                                    type="text"
                                    name="roll_number"
                                    value={formData.roll_number}
                                    onChange={handleChange}
                                    placeholder="Enter Roll Number"
                                />
                                </Form.Group>
                                </Col>
                                <Col sm={12} md={6} lg={6} xl={6}>
                                   <Form.Group className="mb-3" controlId="formBasicEmail">
                                     <Form.Label>Student Name</Form.Label>
                                        <Form.Control
                                        type="text"
                                        name="fullname"
                                        value={formData.fullname}
                                        onChange={handleChange}
                                        // placeholder="Enter Roll Number"
                                    />
                                    </Form.Group>
                                </Col>
                                <Col sm={12} md={6} lg={6} xl={6}>
                                   <Form.Group className="mb-3" controlId="formBasicEmail">
                                     <Form.Label>Student Address</Form.Label>
                                     <Form.Control
                                        type="text"
                                        name="address"
                                        value={formData.address}
                                        onChange={handleChange}
                                        // placeholder="Enter Roll Number"
                                    />
                                    </Form.Group>
                                </Col>
                                <Col sm={12} md={6} lg={6} xl={6}>
                                   <Form.Group className="mb-3" controlId="formBasicEmail">
                                     <Form.Label>Student Study Program</Form.Label>
                                     <Form.Control
                                        type="text"
                                        name="program"
                                        value={formData.program}
                                        onChange={handleChange}
                                        // placeholder="Enter Roll Number"
                                    />
                                    </Form.Group>
                                </Col>
                            </Row>
                        </Form>
                        <div className='title-wrap'>
                           <h3>Student Guardian/Parent Details</h3>
                        </div>
                        <Form className='forms-detail'>
                            <Row>
                                <Col sm={12} md={6} lg={6} xl={6}>
                                   <Form.Group className="" controlId="formBasicEmail">
                                     <Form.Label>Full Name</Form.Label>
                                     <Form.Control
                                        type="text"
                                        name="guardian_name"
                                        value={formData.guardian_name}
                                        onChange={handleChange}
                                        // placeholder="Enter Roll Number"
                                    />
                                    </Form.Group>
                                </Col>
                                <Col sm={12} md={6} lg={6} xl={6}>
                                   <Form.Group className="" controlId="formBasicEmail">
                                     <Form.Label>Valid Email</Form.Label>
                                     <Form.Control
                                        type="text"
                                        name="email"
                                        value={formData.email}
                                        onChange={handleChange}
                                        // placeholder="Enter Roll Number"
                                    />
                                    </Form.Group>
                                </Col>
                            </Row>
                        </Form>
                        <div className='student-btn'>
                        <Button className="add-btn" onClick={handleSubmit}>Add Student</Button>
                        </div>
                    </Container>
                </Modal.Body>
            </Modal>
        </div>
    )
}

export default AddStudent