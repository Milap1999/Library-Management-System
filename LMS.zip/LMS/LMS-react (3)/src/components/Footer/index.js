import React from 'react'
import './style.scss';
import { Col, Container, Row } from 'react-bootstrap';
import logo from '../../assets/Images/logo.png';
import facebook from '../../assets/Images/facebook.svg';
import twitter from '../../assets/Images/twitter.svg';
import instagram from '../../assets/Images/instagram.svg';
import youtube from '../../assets/Images/youtube.svg';
import linkedin from '../../assets/Images/linkedin-in.svg';
const Footer = () => {
    return (
        <footer>
            <div className="footer-content">
                <Container>
                    <Row>
                        <Col sm={12} md={4} lg={4} xl={4} >
                            <h3 className='footer-title'>About Us</h3>
                            <img src={logo} alt='logo' />
                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                        </Col>
                        <Col className='quick-link-wrap' sm={12} md={4} lg={4} xl={4} >
                            <h3 className='footer-title'>Quick Links</h3>
                            <ul className='quick-links'>
                                <li>Let Us Help You</li>
                                <li>Donation</li>
                                <li>About Us</li>
                                <li>Privacy Notice</li>
                                <li>Careers</li>
                            </ul>
                        </Col>
                        <Col sm={12} md={4} lg={4} xl={4} >
                            <h3 className='footer-title'>Social Links</h3>
                            <ul className="socials">
                                <li><a href="#"><img src={facebook} alt="facebook"/></a></li>
                                <li><a href="#"><img src={twitter} alt="twitter"/></a></li>
                                <li><a href="#"><img src={instagram} alt="instagram"/></a></li>
                                <li><a href="#"><img src={youtube} alt="youtube"/></a></li>
                                <li><a href="#"><img src={linkedin} alt="linkedin"/></a></li>
                            </ul>
                        </Col>
                    </Row>
                </Container>
            </div>
            <div className="footer-bottom">
                <p>All Right Reserved &copy; <a href="#">LMS</a></p>
            </div>
        </footer>
    )
}

export default Footer