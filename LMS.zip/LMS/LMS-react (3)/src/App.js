import Routing from './Routing';
import './App.css';

function App() {
  return (
    <>
     <Routing/>
    </>
  );
}

export default App;
